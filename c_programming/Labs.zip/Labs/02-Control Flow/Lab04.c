/*
 ============================================================================
 Name        : Lab04.c
 Author      : Khaled Naga
 Version     : 1
 Copyright   : AMIT Learning
 Description : This program is part of C Course On AMIT Learning
 ========================================================
 Implement a program that takes an input value from the user, and
 prints the summation result of the odd the numbers, from 0 to the
 given input value
 * Use �for� statement
 ============================================================================
*/

#include <stdio.h>

int main(void)
{
	
	return 0;
}
