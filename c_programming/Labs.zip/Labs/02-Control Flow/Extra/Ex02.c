/*
 * Ex05.c
 * Session 2: Loops and decisions
 *  Created on: Jul 10, 2015
 *      Author: Alaa
 */
// purpose: This program is part of C Course On AMIT Learning

/* *******************************************************
 * Write a C code that finds the largest and the smallest of
 * four integers entered by the user
 * *****************output sample**************************
 * Enter four integers: 21 43 10 35
 * Largest: 43
 * Smallest: 10
 * ********************************************************
 */

#include<stdio.h>


int main(void){
	/*** YOUR CODE HERE ***/
return 0;
}
