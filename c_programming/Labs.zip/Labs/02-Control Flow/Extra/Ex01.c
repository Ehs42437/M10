/*
 * Ex02.c
 * Session 2: Loops and decisions
 *  Created on: Jul 10, 2015
 *      Author: Alaa
 */
// purpose: This program is part of C Course On AMIT Learning

/* *******************************************************
 * Write a C code that asks the user to enter a three digits
 * number then prints the number with its digits reversed
 * *****************output sample**************************
 * Enter a two digit number: 287
 * The reversal is: 782
 * ********************************************************
 */

#include <stdio.h>

int main (void){
	/*** YOUR CODE HERE ***/
return 0;
}
