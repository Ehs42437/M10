/*
 * Ex09.c
 * Session 2: Loops and decisions
 *  Created on: Jul 8, 2015
 *      Author: Alaa
 */
// purpose: This program is part of C Course On AMIT Learning

/* *******************************************************
 * Write a C code that check whether a number is prime
 * *****************output sample**************************
 * Enter a number: 3
 * 3 is prime
 *
 * Enter a number: 4
 * 4 is divisible by 2
 * ********************************************************
 */
/* Notes: please refer to >> https://en.wikipedia.org/wiki/Prime_number
 * if you don't remember what's prime number
 */
#include<stdio.h>


int main(void){
	/*** YOUR CODE HERE ***/

return 0;
}
