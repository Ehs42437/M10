/*
 ============================================================================
 Name        : Ex09.c
 Author      : Alaa
 Version     : Aug, 2015
 Copyright   : AMIT Learning
 Description : This program is part of C Course On AMIT Learning
 	 	 	   Session 1: Introduction
 ========================================================
 Write a code that swaps two integers entered by user
 =================output sample==========================
 Enter 2 integer numbers: 2 10
 Your input after swapping: 10 2
 ============================================================================
 */