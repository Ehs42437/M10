/*
 ============================================================================
 Name        : Lab01.c
 Author      : Khaled Naga
 Version     : 1
 Copyright   : AMIT Learning
 Description : This program is part of C Course On AMIT Learning
 ========================================================
 Implement a program that takes 2 input numbers from the user,
 and prints the following:
 + First Number
 + Second Number
 + Addition Result
 + Subtraction Result
 + Multiplication Result
 + Division Result
 + Remainder Result
 Use proper displaying statement for each displayed value
 ============================================================================
*/

